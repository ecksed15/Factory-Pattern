
package com.mycompany.factorypatternexample;


public class Poodle implements Dog{

    @Override
    public void wuff() {
        System.out.println("The poodle says wuuf.");
    }
    
}
class Rottweiler implements Dog
{

    @Override
    public void wuff() {
        System.out.println("The Rottweiler says (very deep) wuuff");
        
    }
}

class Husky implements Dog
{

    @Override
    public void wuff() {
        System.out.println("The Husky say wufufuf");
    }
 
}

