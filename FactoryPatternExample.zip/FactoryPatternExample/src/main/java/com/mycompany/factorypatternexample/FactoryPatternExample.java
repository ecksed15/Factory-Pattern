
package com.mycompany.factorypatternexample;


public class FactoryPatternExample {
    
    public static void main(String[] args)
  {
    // create a small dog
    Dog dog = DogFactory.getDog("small");
    dog.wuff();

    // create a big dog
    dog = DogFactory.getDog("big");
    dog.wuff();

    // create a cool dog
    dog = DogFactory.getDog("cool");
    dog.wuff();
  }
    
}
