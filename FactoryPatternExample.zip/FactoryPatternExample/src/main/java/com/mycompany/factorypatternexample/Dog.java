
package com.mycompany.factorypatternexample;


public interface Dog {
    
    public void wuff();
}
